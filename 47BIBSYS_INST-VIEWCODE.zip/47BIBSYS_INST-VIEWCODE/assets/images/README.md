SIKT: Denne filen styrer hvilken logo som vises i venstre hjørnet i Oria. For å erstatte default Sikt-logo må man legge inn en fil som heter nøyaktig det samme som nåværende fil:

library-logo.png