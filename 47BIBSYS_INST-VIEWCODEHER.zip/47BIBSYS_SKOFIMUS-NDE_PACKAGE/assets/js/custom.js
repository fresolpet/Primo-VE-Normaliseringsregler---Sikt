console.log('Helo from custom js');

/**
 * Hide Unwanted 856 Links Module
 */
angular.module('hideUnwantedLinks', []).run(function () {
  // Blacklist of link texts to hide
  const blacklist = [
  'Originalt bilde',
  'Omslagsbilde',
  'Miniatyrbilde',
  'Forlagets beskrivelse (lang)',
  'Forlagets beskrivelse (kort)',
  'Beskrivelse fra forlaget (kort)',
  'Beskrivelse fra forlaget (lang)',
  'Nettbiblioteket Fulltekst Søke-URL',
  'Nettbiblioteket Fulltekst Digital representasjon'
  ];

  // Function to filter links
  function filterLinks() {
    const serviceLinksComponents = document.querySelectorAll('prm-service-links');
    let linksFilteredCount = 0; // Track how many links were filtered in this run

    serviceLinksComponents.forEach(serviceLinks => {
      const links = serviceLinks.querySelectorAll('[ng-bind-html="link.displayLabel"]'); // Removed :not(.filtered-link)
      links.forEach(link => {
        const linkText = link.textContent.trim();
        if (blacklist.includes(linkText)) {
          const container = link.closest('div[ng-repeat]');
          if (container) {
            container.style.display = 'none'; // Hide the link container
            linksFilteredCount++; // Increment the filtered counter
            console.log(`Hiding link: "${linkText}" - SIKT JS`); // Always log the name of the link being hidden
          }
        }
      });
    });

    // Log only if new links were filtered
    if (linksFilteredCount > 0) {
      console.log(`Filtered ${linksFilteredCount} new links in prm-service-links components - SIKT JS`);
    }
  }

  // Set up a MutationObserver to monitor dynamic changes
  const observer = new MutationObserver(() => filterLinks());
  observer.observe(document.body, { childList: true, subtree: true });

  // Run the filter function initially
  function runInitialFiltering() {
    filterLinks();
    console.log('Initial filtering of prm-service-links completed - SIKT JS'); // Ensure this message is logged
  }

  // Ensure the initial filtering runs correctly
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      setTimeout(runInitialFiltering, 1000); // Delay slightly to ensure AngularJS components are rendered
    });
  } else {
    // If DOM is already loaded, run immediately
    setTimeout(runInitialFiltering, 1000);
  }

  // Debugging: Log when the module is initialized
  console.log('Hide Unwanted Links module initialized - SIKT JS');
});
/**
 * Hide Unwanted 856 Links Module
 */